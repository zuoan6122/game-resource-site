// 游戏资源站计数后端（腾讯云开发 CloudBase 云函数）
// 通过 HTTP 网关暴露：/click、/download、/top、/all、/all-downloads
const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type'
}

function ok(data) {
  return {
    statusCode: 200,
    headers: Object.assign({ 'Content-Type': 'application/json' }, CORS_HEADERS),
    body: JSON.stringify(data)
  }
}

// 原子自增；文档不存在时创建
async function increment(game, field) {
  const col = db.collection('counters')
  try {
    await col.doc(game).update({
      data: { [field]: db.command.inc(1) }
    })
  } catch (e) {
    try {
      await col.add({
        data: {
          _id: game,
          views: field === 'views' ? 1 : 0,
          downloads: field === 'downloads' ? 1 : 0
        }
      })
    } catch (e2) {
      // 并发创建冲突时重试更新
      await col.doc(game).update({
        data: { [field]: db.command.inc(1) }
      })
    }
  }
}

// 分页拉取全部文档（单次 get 上限 100 条）
async function getAllDocs() {
  const MAX = 100
  const col = db.collection('counters')
  let all = []
  let skip = 0
  for (;;) {
    const res = await col.skip(skip).limit(MAX).get()
    all = all.concat(res.data)
    if (res.data.length < MAX) break
    skip += MAX
  }
  return all
}

exports.main = async (event) => {
  const { httpMethod, path, queryStringParameters } = event

  if (httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: CORS_HEADERS, body: '' }
  }

  try {
    if (path === '/click' && httpMethod === 'POST') {
      const game = queryStringParameters && queryStringParameters.game
      if (!game) return ok({ error: 'missing game' })
      await increment(game, 'views')
      return ok({ ok: true })
    }

    if (path === '/download' && httpMethod === 'POST') {
      const game = queryStringParameters && queryStringParameters.game
      if (!game) return ok({ error: 'missing game' })
      await increment(game, 'downloads')
      return ok({ ok: true })
    }

    if (path === '/top' && httpMethod === 'GET') {
      const limit = parseInt((queryStringParameters && queryStringParameters.limit) || '10', 10)
      const res = await db.collection('counters')
        .orderBy('views', 'desc')
        .limit(Math.min(limit, 100))
        .get()
      return ok(res.data.map(d => ({ name: d._id, count: d.views || 0 })))
    }

    if (path === '/all' && httpMethod === 'GET') {
      const docs = await getAllDocs()
      return ok(docs.map(d => ({ name: d._id, count: d.views || 0 })))
    }

    if (path === '/all-downloads' && httpMethod === 'GET') {
      const docs = await getAllDocs()
      return ok(docs.map(d => ({ name: d._id, count: d.downloads || 0 })))
    }

    return { statusCode: 404, headers: CORS_HEADERS, body: JSON.stringify({ error: 'Not Found' }) }
  } catch (e) {
    return { statusCode: 500, headers: CORS_HEADERS, body: JSON.stringify({ error: String(e) }) }
  }
}
